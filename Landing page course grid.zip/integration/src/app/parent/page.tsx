import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { DashCard } from "@/components/dash/card";
import { GlassCard } from "@/components/dash/glass-card";
import { StatRing } from "@/components/dash/stat-ring";
import { ProgressBars } from "@/components/dash/progress-bars";

const SUBJECTS = [
  { name: "Kibertəhlükəsizlik", pct: 82 },
  { name: "Şəbəkə", pct: 92 },
  { name: "Linux", pct: 86 },
  { name: "Python", pct: 78 },
  { name: "Veb təhlükəsizliyi", pct: 67 },
  { name: "CTF", pct: 54 },
];

const MINOR_STATS = [
  { label: "Öyrənmə inkişafı", value: "82%" },
  { label: "Ev tapşırığı", value: "91%" },
  { label: "Bal", value: "1 240" },
];

export default function ParentDashboard() {
  return (
    <main className="mx-auto max-w-[1240px] px-6 pb-20 pt-11 md:px-11">
      {/* Ambient warm glow — decorative only */}
      <div
        aria-hidden
        className="pointer-events-none fixed -right-56 -top-80 -z-10 h-[820px] w-[1000px] animate-blob rounded-full blur-[30px]"
        style={{ background: "radial-gradient(closest-side, rgba(255,107,0,0.13), rgba(255,107,0,0) 78%)" }}
      />

      <header className="mb-13 flex items-start justify-between gap-8 [animation:count-up_0.5s_ease_both]">
        <div>
          <h1 className="font-display text-[40px] font-semibold leading-[1.12] tracking-[-0.032em]">
            Axşamınız xeyir, Elvin.
          </h1>
          <p className="mt-3 text-[16.5px] tracking-[-0.005em] text-grey-500">
            Ali bu həftə necə irəliləyir.
          </p>
        </div>
      </header>

      {/* Child + attendance */}
      <section className="mb-5 grid gap-5 [grid-template-columns:repeat(auto-fit,minmax(320px,1fr))]">
        <DashCard className="rounded-[26px] p-[30px]">
          <div className="flex items-center gap-[18px]">
            <span className="flex h-[62px] w-[62px] shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-grey-100 to-grey-200 font-display text-[19px] font-semibold text-navy-600">
              AM
            </span>
            <div className="min-w-0 flex-1">
              <div className="font-display text-xl font-semibold tracking-[-0.02em]">Ali Məmmədov</div>
              <div className="mt-1 text-[13.5px] text-grey-500">14 yaş · Kibertəhlükəsizlik</div>
            </div>
          </div>
          <div className="my-6 flex items-center gap-2.5">
            <span className="inline-flex items-center gap-[7px] rounded-[9px] bg-electric-500/10 px-3 py-1.5 text-xs font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-electric-500" />
              Səviyyə 12
            </span>
            <span className="rounded-[9px] bg-grey-100 px-3 py-1.5 text-xs font-medium text-navy-600">2-ci il</span>
          </div>
          <Link
            href="/parent/children"
            className="block w-full rounded-2xl border border-dash-ink/[0.08] bg-white py-3.5 text-center text-[13px] font-semibold transition hover:-translate-y-px hover:bg-grey-50 dark:bg-transparent"
          >
            Övladı dəyişdir
          </Link>
        </DashCard>

        <DashCard className="flex items-center gap-[30px] rounded-[26px] p-[30px]">
          <StatRing value={94} />
          <div className="min-w-0">
            <div className="text-[11px] font-semibold uppercase tracking-[0.09em] text-grey-500">Davamiyyət</div>
            <div className="my-2 font-display text-[17px] font-semibold tracking-[-0.02em]">Əla davamiyyət</div>
            <div className="flex flex-col gap-2 text-[13px]">
              {[
                ["İştirak", "23", "bg-electric-500"],
                ["Gecikmə", "1", "bg-dash-ink/25"],
                ["Qayıb", "1", "bg-dash-ink/10"],
              ].map(([label, value, dot]) => (
                <div key={label} className="flex items-center gap-2.5">
                  <span className={`h-[7px] w-[7px] rounded-full ${dot}`} />
                  <span className="flex-1 text-grey-500">{label}</span>
                  <span className="font-semibold tabular-nums">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </DashCard>
      </section>

      {/* Secondary metrics */}
      <section className="mb-5 grid gap-5 [grid-template-columns:repeat(auto-fit,minmax(160px,1fr))]">
        {MINOR_STATS.map((m) => (
          <div
            key={m.label}
            className="rounded-[22px] border border-dash-ink/[0.045] bg-white/55 px-6 py-[22px] dark:bg-white/[0.03]"
          >
            <div className="text-[11px] font-semibold uppercase tracking-[0.09em] text-grey-500">{m.label}</div>
            <div className="mt-3 font-display text-[27px] font-semibold tracking-[-0.03em]">{m.value}</div>
          </div>
        ))}
      </section>

      {/* Learning progress */}
      <DashCard className="mb-5 rounded-[28px] p-9">
        <div className="mb-[34px]">
          <h2 className="font-display text-[23px] font-semibold tracking-[-0.025em]">Öyrənmə inkişafı</h2>
          <p className="mt-2 text-[14.5px] text-grey-500">Ali cari fənlər üzrə sabit şəkildə irəliləyir.</p>
        </div>
        <ProgressBars subjects={SUBJECTS} />
      </DashCard>

      {/* Next lesson */}
      <section className="grid gap-5 [grid-template-columns:repeat(auto-fit,minmax(340px,1fr))]">
        <GlassCard className="flex flex-col rounded-[26px]">
          <div className="mb-6 flex items-center gap-2.5">
            <span className="h-1.5 w-1.5 rounded-full bg-electric-500" />
            <span className="text-[11px] font-semibold uppercase tracking-[0.09em] text-grey-500">Növbəti dərs</span>
          </div>
          <h3 className="font-display text-[22px] font-semibold leading-[1.28] tracking-[-0.025em]">
            Kibertəhlükəsizliyin əsasları
          </h3>
          <div className="my-[18px] flex items-center gap-4 text-sm">
            <span className="font-semibold">Bugün · 18:00</span>
            <span className="h-3.5 w-px bg-dash-ink/15" />
            <span className="text-grey-500">90 dəqiqə</span>
          </div>
          <div className="flex items-center gap-3 border-t border-dash-ink/[0.07] pt-[22px]">
            <span className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full bg-grey-100 text-xs font-semibold text-navy-600">
              NƏ
            </span>
            <div>
              <div className="text-[13.5px] font-semibold">Nicat Əliyev</div>
              <div className="mt-0.5 text-xs text-grey-500">Kibertəhlükəsizlik müəllimi</div>
            </div>
          </div>
          <button className="mt-7 w-full rounded-[15px] bg-electric-500 py-[15px] text-[13.5px] font-semibold text-white shadow-[0_12px_26px_-12px_rgba(255,107,0,0.6)] transition hover:-translate-y-px">
            Dərsə keç
          </button>
        </GlassCard>

        <div className="rounded-[26px] border border-dash-ink/[0.04] bg-grey-100/70 p-9 dark:bg-white/[0.03]">
          <div className="mb-[22px] text-[11px] font-semibold uppercase tracking-[0.09em] text-grey-500">
            Müəllim qeydi
          </div>
          <p className="mb-6 font-display text-[19px] font-normal leading-[1.55] tracking-[-0.015em] [text-wrap:pretty]">
            &ldquo;Ali bu ay şəbəkə və Linux mövzularında xüsusilə güclü inkişaf göstərdi. Laboratoriya
            tapşırıqlarına yanaşması çox məsuliyyətlidir.&rdquo;
          </p>
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-grey-200 text-[11.5px] font-semibold text-navy-600">
              NƏ
            </span>
            <div className="flex-1">
              <div className="text-[13px] font-semibold">Nicat Əliyev</div>
              <div className="mt-0.5 text-xs text-grey-500">Kibertəhlükəsizlik müəllimi</div>
            </div>
            <span className="text-xs text-grey-500">30 Avq 2026</span>
          </div>
        </div>
      </section>
    </main>
  );
}
