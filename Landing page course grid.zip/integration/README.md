# Parent Portal UI — integration

Drop these into your Next.js app. Paths below are relative to the repo root.

## 1. Replace (this is the nav fix)

    src/components/dash/rail.tsx

Two changes:
- **Mobile bottom nav**: the oversized `bg-electric-500` pill around the active
  item is gone. Active = orange icon + bold dark label + a 4px orange dot.
  Labels are now shown under each icon.
- **Active state logic**: `activeHref` picks the **longest** matching href, so
  `/parent` no longer stays lit while you're on `/parent/homework`. It is derived
  from `usePathname()` on every render — nothing is held in local state, so the
  previous item can never remain visually active.

No change needed in `layout.tsx` or `lib/nav.tsx` — same `DashNavItem[]` props.

## 2. Add

    src/components/dash/glass-card.tsx
    src/components/dash/stat-ring.tsx
    src/components/dash/progress-bars.tsx

`stat-ring` and `progress-bars` are client components (they animate on mount).

## 3. Replace

    src/app/parent/page.tsx

Currently hardcoded to the mock student. Swap `SUBJECTS` / `MINOR_STATS` and the
child block for your `getCurrentParent()` data.

## Tokens

Everything uses tokens already in `tailwind.config.ts` — `electric-500`,
`grey-*`, `dash-*`, `font-display`, `animate-blob`. Nothing new to add.

## Not included

The remaining screens (attendance calendar, homework filters, payments ledger,
notifications, settings) exist in the prototype but aren't converted yet — say
which one you want next.
