# Student dashboard — integration

## 1. Add two files

    src/components/dash/level-ring.tsx
    src/components/dash/streak-week.tsx

Both are small; `level-ring` is a client component (animates on mount),
`streak-week` is a server component.

## 2. Replace

    src/app/student/page.tsx

## What it reads (all already in your schema)

| UI | Source |
| --- | --- |
| Greeting, avatar, level pill | `student.firstName`, `avatarUrl`, `level` |
| Next lesson | `prisma.lesson.findFirst` over `enrollments[].classId` |
| Today's task | `prisma.submission` where status PENDING/OVERDUE |
| Continue learning | `enrollments[0].course` + `averageProgress(progress)` |
| XP / level ring | `student.xp`, `student.points`, `student.level` |
| Streak | `student.streakDays` |
| Progress bars | `student.progress[]` → `{ skill, percent }` |
| Attendance ring | `attendanceRate(student.attendance)` |
| Projects | `student.projects[]` → `title`, `technologies`, `courseTag` |
| Achievements | `student.studentBadges[].badge` → `name`, `emoji` |
| Recent activity | `prisma.submission` where `submittedAt` not null |

No new Prisma fields, no new dependencies, no `tailwind.config.ts` change.

## Two things to know

**Strings are inline Azerbaijani**, not `dict.*` — so it drops in without
editing `src/i18n`. If you want them translated, move them into
`dict.studentDashboard` and swap the literals.

**`nextLevelXp()`** at the top of the page is a placeholder curve
(`(level + 1) * 125`). Replace it with your real level formula if you have one.

## Not converted yet

The prototype also has İnkişaf, Davamiyyət, Layihələr and Reytinq as separate
full screens. Your repo already has `/student/portfolio`, `/student/leaderboard`,
`/student/homework` and `/student/settings` — say which one to convert next.
