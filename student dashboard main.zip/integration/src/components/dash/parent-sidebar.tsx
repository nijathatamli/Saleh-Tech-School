"use client";

import Link from "next/link";
import { Logo } from "@/components/app/logo";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { getActiveHref } from "@/components/dash/rail";
import type { DashNavItem } from "@/components/dash/sidebar";

/* Floating glass rail — matches the approved Parent Portal prototype.
 * Same props and same active-href logic as before; only the shell styling
 * changed (fixed inset-22px card, rounded-[30px], backdrop blur) plus a
 * scrollable nav list so the user footer can never be pushed off-screen. */
export function ParentSidebar({
  items,
  brandHref,
  badges,
  user,
  roleLabel,
}: {
  items: DashNavItem[];
  brandHref: string;
  badges?: Record<string, number>;
  user: { name: string; avatarUrl?: string | null };
  roleLabel: string;
}) {
  const pathname = usePathname();
  const activeHref = getActiveHref(items, brandHref, pathname);

  return (
    /* Spacer keeps page content clear of the fixed rail */
    <div className="hidden w-[280px] shrink-0 md:block">
      <aside
        className={cn(
          "fixed bottom-[22px] left-[22px] top-[22px] z-20 flex w-[236px] flex-col rounded-[30px] px-3.5 py-[22px]",
          "border border-dash-ink/[0.055] bg-white/60 backdrop-blur-[22px] backdrop-saturate-[1.7]",
          "shadow-[0_1px_0_rgba(255,255,255,0.7)_inset,0_22px_50px_-30px_rgba(23,23,23,0.28)]",
          "dark:border-white/10 dark:bg-white/[0.05]"
        )}
      >
        <Link href={brandHref} className="mb-[26px] flex items-center px-3 pt-1.5">
          <Logo size={16} />
        </Link>

        <nav className="min-h-0 flex-1 space-y-[3px] overflow-y-auto">
          {items.map((item) => {
            const active = item.href === activeHref;
            const count = badges?.[item.href];
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border px-3.5 py-2.5 text-[13.5px] tracking-[-0.005em] transition-colors",
                  active
                    ? "border-electric-500/20 bg-electric-500/[0.09] font-semibold text-dash-ink dark:text-white"
                    : "border-transparent font-medium text-dash-ink/55 hover:bg-dash-ink/[0.04] hover:text-dash-ink dark:text-white/50 dark:hover:bg-white/5 dark:hover:text-white"
                )}
              >
                <span className={cn("w-[18px] shrink-0 text-center", active && "text-electric-500")}>{item.icon}</span>
                <span className="min-w-0 flex-1 truncate">{item.label}</span>
                {!!count && (
                  <span
                    className={cn(
                      "flex h-[19px] min-w-[19px] shrink-0 items-center justify-center rounded-full px-1.5 text-[10.5px] font-bold",
                      active ? "bg-electric-500 text-white" : "bg-dash-ink/[0.08] text-dash-ink/70 dark:bg-white/10 dark:text-white/70"
                    )}
                  >
                    {count}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="mt-4 flex shrink-0 items-center gap-3 border-t border-dash-ink/[0.06] pl-2 pt-[18px]">
          <Avatar name={user.name} src={user.avatarUrl} size={34} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[12.5px] font-semibold text-dash-ink dark:text-white">{user.name}</p>
            <p className="mt-px truncate text-[11px] text-dash-muted">{roleLabel}</p>
          </div>
        </div>
      </aside>
    </div>
  );
}
