# Integration prompt for Claude Code

Copy everything below the line into Claude Code, running in the
`Saleh-Tech-School` repo root.

---

Integrate two already-designed dashboard UIs into this Next.js app. The design
work is done — your job is **only** to wire the provided files into the app
correctly. Do not redesign, do not "improve" the visuals, do not change colors,
spacing, radii, or typography.

## Context about this repo

- Next.js 14 App Router, TypeScript, Tailwind, Prisma + Postgres, next-auth.
- Design tokens already exist in `tailwind.config.ts`: `electric-500` (#FF6B00),
  `electric-600` (#E66000), `grey-*`, `navy-*`, and a warm `dash-*` set
  (`dash-paper`, `dash-ink`, `dash-rule`, `dash-muted`, `dash-dark-*`).
  Fonts: `font-display` and `font-app`. Animations: `animate-blob`, `count-up`.
- Shared dashboard primitives already exist in `src/components/dash/`:
  `card.tsx` (DashCard), `glass-card.tsx` (GlassCard), `stat-ring.tsx`
  (StatRing), `progress-bars.tsx` (ProgressBars), `empty-state.tsx`
  (DashEmptyState), `rail.tsx` (DashRail + `getActiveHref`), `sidebar.tsx`
  (DashNavItem type), `ledger.tsx`, `parent-topbar.tsx`, `parent-sidebar.tsx`.
- `src/components/ui/avatar.tsx` exports `Avatar` (props: `name`, `src`, `size`).
- Helpers in `src/lib/utils.ts`: `cn`, `formatDate`, `formatAzn`,
  `attendanceRate`, `averageProgress`, `averageGrade`,
  `monthlyAttendanceByClass`, `initials`.
- Data loaders in `src/lib/data.ts`: `getCurrentParent()`, `getCurrentStudent()`,
  `getLeaderboard()`, `getUnreadNotificationCount()`.
- Nav item lists in `src/lib/nav.tsx`: `getParentNavItems(dict)`,
  `getStudentNavItems(dict)`.

Relevant Prisma fields (already in the schema — do NOT add migrations):

- `StudentProfile`: `firstName`, `lastName`, `birthDate`, `avatarUrl`, `level`,
  `xp`, `points`, `streakDays`
- `Progress`: `skill`, `percent`
- `Project`: `title`, `description`, `imageUrl`, `technologies` (string[]),
  `courseTag`
- `Badge`: `code`, `name`, `emoji`, `description`; `StudentBadge.earnedAt`
- `Course`: `name`, `durationMonths`, `lessonsPerWeek`, `category`, `level`
- `Submission`: `status` (PENDING | SUBMITTED | GRADED | OVERDUE),
  `submittedAt`, `score`, `feedback`, related `homework.title`,
  `homework.dueDate`
- `Enrollment` has `classId` and a `course` relation

## Task 1 — replace the parent sidebar shell

Replace `src/components/dash/parent-sidebar.tsx` with the provided file.

It keeps the exact same props (`items`, `brandHref`, `badges`, `user`,
`roleLabel`) and still calls `getActiveHref` from `@/components/dash/rail`, so
`src/app/parent/layout.tsx` must NOT change.

The only difference is the shell styling: a fixed floating glass rail
(`fixed left-[22px] top-[22px] bottom-[22px] w-[236px] rounded-[30px]`,
`bg-white/60 backdrop-blur-[22px]`) wrapped in a `w-[280px]` spacer div so page
content stays clear of it. The nav list scrolls (`min-h-0 flex-1 overflow-y-auto`)
so the user footer can never be pushed off-screen.

Verify after: `/parent` renders with the floating rail, the active item is the
longest matching href (so `/parent` is NOT lit while on `/parent/homework`), and
badge counts still appear on `/parent/homework` and `/parent/notifications`.

## Task 2 — student dashboard

Add these two new files:

- `src/components/dash/level-ring.tsx` — client component, same ring geometry as
  `StatRing` (r=52, 120x120 viewBox, `-rotate-90`) but the centre shows the
  level number instead of a percent. Animates `strokeDashoffset` on mount.
- `src/components/dash/streak-week.tsx` — server component, 7-day strip driven
  by `student.streakDays`.

Then replace `src/app/student/page.tsx` with the provided file.

Section order (this is the intended hierarchy — keep it):

1. Greeting header + level pill + avatar
2. **Bu gün** — next lesson (dark card) | today's task (white card)
3. Öyrənməyə davam et — current course + overall progress
4. XP card | Level ring + streak
5. Sənin inkişafın (ProgressBars) | attendance ring (GlassCard)
6. Mənim layihələrim — up to 3 project cards
7. Nailiyyətlər | Son fəaliyyət

Data mapping:

| UI | Source |
| --- | --- |
| Next lesson | `prisma.lesson.findFirst` where `classId in enrollments[].classId` and `date >= now`, ordered `date asc`, including `class.teacher.user` |
| Today's task | `prisma.submission.findMany` where status in PENDING/OVERDUE, ordered by `homework.dueDate asc` — take the first |
| Continue learning | `enrollments[0].course` + `averageProgress(student.progress)` |
| XP / level | `student.xp`, `student.points`, `student.level` |
| Streak | `student.streakDays` |
| Progress bars | `student.progress` → `{ name: p.skill, pct: p.percent }` |
| Attendance | `attendanceRate(student.attendance)` |
| Projects | `student.projects` → `title`, `technologies`, `courseTag` |
| Achievements | `student.studentBadges` sorted by `earnedAt desc`, take 6 |
| Recent activity | `prisma.submission` where `submittedAt` not null, ordered desc, take 4 |

Keep `export const dynamic = "force-dynamic";`.

## Constraints

- **No new npm packages.** Icons come from `lucide-react` (already installed).
- **No `tailwind.config.ts` edits.** Every class used already resolves.
- **No Prisma migrations.** Every field read already exists.
- Do not touch the admin, teacher, or marketing/public routes.
- Do not touch `src/app/parent/page.tsx` — it is already integrated and correct.
- Strings in the new student page are inline Azerbaijani rather than `dict.*`,
  so `src/i18n` needs no changes. Leave them as-is unless I ask for i18n.
- `nextLevelXp()` at the top of the student page is a placeholder curve
  (`(level + 1) * 125`). Leave it; I will replace it with the real formula.

## Definition of done

- `npx tsc --noEmit` passes.
- `npm run build` passes.
- `/parent` and `/student` both render logged in as the seeded parent and
  student users, with no console errors.
- Mobile width (<768px): the bottom glass nav from `rail.tsx` shows, the active
  item is an orange icon + bold dark label + a 4px orange dot — NOT a filled
  pill or circle.
- Report anything you had to change beyond the files I provided, and why.
